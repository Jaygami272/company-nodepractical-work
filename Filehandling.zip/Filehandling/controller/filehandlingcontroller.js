
const fs = require("fs").promises;
const path = require("path");
const insertdata = async (req, res) => {
    const now = new Date();
    const filepath = path.join(__dirname, `../uploads/${req.file.filename}`);
    const content = `\n${req.body.firstname},${req.body.lastname},${now.toISOString()}`
    await fs.writeFile(filepath, content, { flag: 'a+' });

    const data = await fs.readFile(filepath, 'utf-8');

    const rowarray = data.split("\n").filter(row => row.trim() != "");
    let date;
    const dataarray = rowarray.map(r => {
        row = r.split(",");
        date = new Date(row[2]);
        row[2] = date.toLocaleString();

        return row;

    });


    res.render('display', { dataarray, filename: req.file.filename });
}

const deletedata = async (req, res) => {

    const filepath = path.join(__dirname, `../uploads/${req.query.filename}`);
    const data = await fs.readFile(filepath, 'utf-8');

    const rowarray = data.split("\n");

    const dataarray = rowarray.filter(function (d) {
        const [firstname] = d.split(",");
        return !(firstname == req.query.id);
    });

    let content = "";

    dataarray.forEach(actual => {
        content += `${actual}\n`
    });

    await fs.writeFile(filepath, content, { flag: 'w' });

    const data2 = await fs.readFile(filepath, 'utf-8');

    const rowarray2 = data2.split("\n").filter(row => row.trim() != "");

    const dataarray2 = rowarray2.map(r => {
       row = r.split(",");
        date=new Date(row[2]);
       row[2]=date.toLocaleString();

       return row;
    }
    );

    res.render('display', { dataarray: dataarray2, filename: req.query.filename });
}


const updatedata = async (req, res) => {

    const filepath = path.join(__dirname, `../uploads/${req.query.filename}`);
    const data = await fs.readFile(filepath, 'utf-8');

    const rowarray = data.split("\n").filter(row => row.trim() != "");

    const dataarray = rowarray.map(function (updates) {
        let [fname, lname, date] = updates.split(',');
        if (fname == req.query.id) {
            fname = req.body.firstname;
            lname = req.body.lastname;
            date = new Date().toISOString();
        }

        return [fname, lname, date];
    });

    let content = "";
    dataarray.forEach(actual => {
        content += `${actual[0]},${actual[1]},${actual[2]}\n`;
    });

    await fs.writeFile(filepath, content, { flag: 'w' });

    const data1 = await fs.readFile(filepath, 'utf-8');

    const rowarray1 = data1.split("\n").filter(row => row.trim() != "");

    const dataarray1 = rowarray1.map(r => {
        row = r.split(",");
        date = new Date(row[2]);
        row[2] = date.toLocaleString();

        return row;
    });

    res.render('display', { dataarray: dataarray1, filename: req.query.filename });

}
module.exports = {
    insertdata,
    deletedata,
    updatedata
}