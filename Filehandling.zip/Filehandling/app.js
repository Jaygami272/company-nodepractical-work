
require('dotenv').config();
const express=require('express');
const app=express();
 app.use(express.static('public'));
 app.use(express.urlencoded({extended:true}));
 app.set('view engine','ejs');

 const mainrouter=require('./router/mainrouter1');

app.use('/',mainrouter);
 
app.listen(process.env.PORT,(err)=>{
            if(err){
                console.log("problem are occure while start server..")
            }else{
                console.log("Server is running..");
            }
});