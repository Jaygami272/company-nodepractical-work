const express = require('express');

const fs = require('fs');
const path = require('path');
const router = express.Router();
const multer = require('multer');

let filename;
let filepath;
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },

    filename: function (req, file, cb) {
        filename = file.originalname;
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

router.get('/', (req, res) => {
    res.render('first');
});

router.get('/delete', (req, res) => {
    fs.readFile(filepath, 'utf-8', (err, data) => {
        if (err) {
            console.log("Error occure while read file..");
        } else {
            const rowarray2 = data.split("\n");
            let dataarray2 = [];
            rowarray2.forEach(d => {
                let check = d.split(",");
                if (check[0] != req.query.id) {
                    dataarray2.push(check);
                }
            });

            let content2 = "";

            for(let i=0;i<dataarray2.length;i++){
                content2 += `${dataarray2[i][0]},${dataarray2[i][1]}`;
                if(i!=(dataarray2.length-1)){
                    content2+="\n";
                }
                
            }

            
            

            fs.writeFile(filepath, content2, { flag: 'w' }, (err) => {
                if (err) {
                    console.log("Error occure while writing into file..");
                } else {
                    fs.readFile(filepath, 'utf8', (err, data) => {
                        if (err) {
                            console.error('Error reading file:', err);
                            return;
                        }

                        const rowarray = data.split("\n");
                        let dataarray = [];
                        rowarray.forEach(d => {
                            dataarray.push(d.split(','));
                        });
                        console.log(dataarray);
                        if(content2==""){
                            res.render("first");
                        }else{
                        res.render('display', { dataarray });
                        }
                    });
                }
            });
        }
    });

});


router.post('/up', upload.single('myfile'), (req, res) => {

    filepath = path.join(__dirname, `../uploads/${filename}`);
    const content = `\n${req.body.firstname},${req.body.lastname}`;

    fs.writeFile(filepath, content, { flag: 'a+' }, (err) => {
        if (err) throw err;

        fs.readFile(filepath, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                return;
            }

            const rowarray = data.split("\n");
            let dataarray = [];
            rowarray.forEach(d => {
                dataarray.push(d.split(','));
            });
            //console.log(dataarray);

            res.render('display', { dataarray });
        });
    });
});



module.exports = router;