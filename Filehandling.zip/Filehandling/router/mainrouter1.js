const express=require("express");
const router=express.Router();
const multermiddleware=require('../middlewares/multermiddleware');
const filehandiling=require("../controller/filehandlingcontroller");

router.get('/', (req, res) => {
    res.render('first');
});
router.get('/edit',(req,res)=>{
        res.render('edit',{filename:req.query.filename,id:req.query.id});
});
router.post('/up',multermiddleware.upload.single('myfile'),filehandiling.insertdata);
router.get('/delete',filehandiling.deletedata);
router.post('/update',filehandiling.updatedata);

module.exports=router;