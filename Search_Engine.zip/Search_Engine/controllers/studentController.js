const { json } = require('express');
const studentmodel = require('../models/studentModel');

function getfirststudents(req, res) {
    
    
    studentmodel.getstudentdeatils((err, students) => {
        let page = parseInt(req.query.pageno) || 1;
        let pageno = page;
        res.render('studentdata', { students, pageno });
    });
}

function getanotherstudents(req, res) {

    let q=searchstudents(req,res);
    
    studentmodel.changepage(q,req.query.pageno, (err, students) => {
        if (err) throw err;
        res.json(students);
    });
}
// function searchmultiple(req,res){
//      let fname='';
//      let fnamearray=[];
      
//     let lname;
//     let phone;
//     let email;
//     let city;
//     let searchstring = req.query.searchtxt;
//     let stage=req.query.stage_button;

   
//     let i=0;
//     while(i<searchstring.length){
//         if(searchstring[i]=='$'){
//             let j=i+1;
//             while((searchstring[j] != "$" || searchstring[j] != "^" || searchstring[j] != "_" || searchstring[j] != "[" || searchstring[j] != "]") && j<searchstring.length){
//                 fname += searchstring[j];
//                 j++;
//                 i=j;
//             }
        
//             fnamearray.push(fname);
//             // console.log(fnamearray);
//             fname="";
           
//         }

//     }
//     console.log(fnamearray);
    
// }

function searchstudents(req, res) {
    let fname;
    let lname;
    let phone;
    let email;
    let city;
    let searchstring = req.query.searchtxt;
    let stage=req.query.stage_button;
    
    
    if (searchstring.includes("$")) {
        let symbolindex = searchstring.indexOf("$");
        let start = symbolindex + 1;
        while (start <= searchstring.length - 1) {
            if (searchstring[start] == "^" || searchstring[start] == "_" || searchstring[start] == "[" || searchstring[start] == "]") {
                let end = searchstring.indexOf(searchstring[start]);
                fname = (searchstring.slice(symbolindex + 1, end));
                break;
            } else {
                if(start == searchstring.length-1){
                    fname = searchstring.slice(symbolindex + 1);
                    break;
                }
                start++;
            }
        }
       
        
    }

    if (searchstring.includes("^")) {
        let symbolindex = searchstring.indexOf("^");
        let start = symbolindex + 1;
        while (start <= searchstring.length - 1) {
            if (searchstring[start] == "$" || searchstring[start] == "_" || searchstring[start] == "[" || searchstring[start] == "]") {
                let end = searchstring.indexOf(searchstring[start]);
                lname = (searchstring.slice(symbolindex + 1, end));
                break;
            } else {
                if(start == searchstring.length-1){
                    lname = (searchstring.slice(symbolindex + 1));
                    break;
                }
                start++;
            }
        }
       
    }

     if (searchstring.includes("_")) {
        let symbolindex = searchstring.indexOf("_");
        let start = symbolindex + 1;
        while (start <= searchstring.length - 1) {
            if (searchstring[start] == "$" || searchstring[start] == "_" || searchstring[start] == "[" || searchstring[start] == "]") {
                let end = searchstring.indexOf(searchstring[start]);
                phone = (searchstring.slice(symbolindex + 1, end));
                break;
            } else {
                if(start == searchstring.length-1){
                    phone = (searchstring.slice(symbolindex + 1));
                    break;
                }
                start++;
            }
        }
       
    }

     if (searchstring.includes("[")) {
        let symbolindex = searchstring.indexOf("[");
        let start = symbolindex + 1;
        while (start <= searchstring.length - 1) {
            if (searchstring[start] == "$" || searchstring[start] == "_" || searchstring[start] == "[" || searchstring[start] == "]") {
                let end = searchstring.indexOf(searchstring[start]);
                email = (searchstring.slice(symbolindex + 1, end));
                break;
            } else {
                if(start == searchstring.length-1){
                    email = (searchstring.slice(symbolindex + 1));
                    break;
                }
                start++;
            }
        }
       
    }

    if (searchstring.includes("]")) {
        let symbolindex = searchstring.indexOf("]");
        let start = symbolindex + 1;
        while (start <= searchstring.length - 1) {
            if (searchstring[start] == "$" || searchstring[start] == "_" || searchstring[start] == "[" || searchstring[start] == "]") {
                let end = searchstring.indexOf(searchstring[start]);
                city = (searchstring.slice(symbolindex + 1, end));
                break;
            } else {
                if(start == searchstring.length-1){
                    city = (searchstring.slice(symbolindex + 1));
                    break;
                }
                start++;
            }
        }
       
    }
let querystr=``;
    if(fname!=undefined){
        querystr+=` ${stage} first_name LIKE '${fname}%'`
    }
    if(lname!=undefined){
        querystr+=` ${stage} last_name LIKE '${lname}%'`
    }
    if(phone!=undefined){
        querystr+=` ${stage} phone_no LIKE '${phone}%'`
    }
    if(email!=undefined){
        querystr+=` ${stage} email LIKE '${email}%'`
    }
    if(city!=undefined){
        querystr+=` ${stage} city LIKE '${city}%'`
    }
    let q;
    if(stage=='OR'){
        q=querystr.replace('OR','');
    }else{
        q=querystr.replace('AND','');
    }
   return q;
    // studentmodel.search(q,(err,students)=>{
    //         if(err) throw err;
            
    //         res.json(students);
    // });

   
}

module.exports = {
    getfirststudents,
    getanotherstudents,
    searchstudents,
    
}