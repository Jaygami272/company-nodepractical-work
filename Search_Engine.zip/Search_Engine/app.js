require('dotenv').config();
const express=require('express');
const app=express();
const route=express.Router();
app.set('view engine','ejs');
const mainrouter=require('./routers/mainrouter');
app.use(route);


app.use('/',mainrouter);


app.listen(process.env.PORT,()=>{
        console.log("Server is Running....");
});

