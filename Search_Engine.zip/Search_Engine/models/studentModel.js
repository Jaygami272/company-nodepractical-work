const db = require('../configs/db');

function getstudentdeatils(callback) {
    // let pageno=parseInt(page) || 1;
    // let limit=(pageno-1)*20;
    db.query("select student_id,first_name,last_name,email,phone_no,city,date_of_birth from students limit 0,20", callback);
}

let changepage = function (querstr,page, callback) {
    let pageno = parseInt(page) || 1;
    let limit = (pageno - 1) * 20;
    db.query(`select student_id,first_name,last_name,email,phone_no,city,date_of_birth from students where ${querstr || 1} limit ?,20`, [limit], callback);
}

let search = function (querystr,callback) {
    
    // if(stage=='A'){
    // db.query(`select student_id,first_name,last_name,email,phone_no,city,date_of_birth from students where first_name LIKE '${fname}%' AND last_name LIKE '${lname}%' AND phone_no LIKE '${phone}%' AND email LIKE '${email}%' AND city LIKE '${city}%' limit 20`,callback);
    // }
   
    db.query(`select student_id,first_name,last_name,email,phone_no,city,date_of_birth from students where ${querystr || 1} limit 20`,callback);
    
    
   
}
module.exports = {
    getstudentdeatils,
    changepage,
    search
}