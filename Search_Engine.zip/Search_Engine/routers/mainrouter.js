const express=require('express');
const router=express.Router();
const studentcontroller=require('../controllers/studentController');


 router.get('/',studentcontroller.getfirststudents);
 router.get('/students',studentcontroller.getanotherstudents);
 router.get('/search',studentcontroller.getanotherstudents);

module.exports=router;