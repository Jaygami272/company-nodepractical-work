require('dotenv').config();

const mysql=require('mysql2');

const mysqlconnection=mysql.createConnection({
        host:process.env.DB_HOST,
        user:process.env.DB_USER,
        password:process.env.DB_PASSWORD,
        database:process.env.DB_NAME,
        dateStrings:true
});
mysqlconnection.connect((err)=>{

    if(err){
        console.log("problems occure while try to connect with database..")
    }else{
        console.log("Mysql Connection Successfully..");
    }
});
module.exports=mysqlconnection;