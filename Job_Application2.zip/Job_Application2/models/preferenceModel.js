const db=require('../configs/db');

const insertpreference=function(applicantid,body,callback){
            let l='';
            let locationarray=body.location;
            for(let i=0;i<locationarray.length;i++){
                l+=body.location[i];
                if(i!=((locationarray.length)-1)){
                    l+=',';
                }
            }
        // Query for insert data inside preferences table
         db.query("insert into preferances(applicant_id,prefered_location,notice_period,department,expected_ctc,current_ctc) values (?,?,?,?,?,?)",[applicantid,l,body.notice,body.department,body.expactedctc,body.currentctc],callback);
       
}

const deletepreference=(id,callback)=>{
    db.query(`delete from preferances where applicant_id=${id}`,callback);
}


module.exports={
    insertpreference,
    deletepreference
}