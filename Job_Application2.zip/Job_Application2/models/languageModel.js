const db=require('../configs/db');

let getlanguage=function(callback){
        db.query('select language_id,language_name from languages',callback);
}

module.exports={
    getlanguage
}