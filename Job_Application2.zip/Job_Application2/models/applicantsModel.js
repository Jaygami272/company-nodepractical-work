const db = require("../configs/db");

const insertapplicant = (body, callback) => {
  const value = [
    body.fname,
    body.lname,
    body.designation1,
    body.address1,
    body.address2,
    body.email,
    body.country,
    body.state,
    body.city,
    body.zipcode,
    body.phone_no,
    body.gender,
    body.relationship,
    body.dob,
  ];
  db.query(
    "insert into applicants (first_name,last_name,designation,address1,address2,email,country_id,state_id,city_id,zip_code,phone_no,gender,relationship_status,date_of_birth) values (?)",
    [value],
    callback,
  );
};

const getapplicants = function (callback) {
  db.query(
    "select applicant_id,first_name,last_name,designation,email,phone_no from applicants",
    callback,
  );
};

const getapplicantinfromation = function (ids, callback) {
  db.query(
    `select appl.applicant_id,appl.first_name,appl.last_name,appl.designation,appl.address1,appl.address2,appl.email,country.country_name,country.country_id,s.state_name,s.state_id,city.city_name,city.city_id,appl.zip_code,appl.phone_no,appl.gender,appl.relationship_status,appl.date_of_birth from applicants as appl 
        join states as s on appl.state_id=s.state_id 
        join countries as country on appl.country_id=country.country_id 
        join cities as city on appl.city_id=city.city_id  where appl.applicant_id = ?`,
    [ids],
    (err, applicants) => {
      if (err) {
        console.log("error in applicants" + err);
      }

      db.query(
        "select course_name,university_board,passing_year,percentage from educations where applicant_id = ?",
        [ids],
        (err, educations) => {
          if (err) {
            console.log("error in education" + err);
          }

          db.query(
            `select language_name,read_language,write_language,speak_language from languages_known where applicant_id = ? `,
            [ids],
            (err, languages) => {
              if (err) {
                console.log("error in language" + err);
              }

              db.query(
                `select technology_name,levels from technologies_known where applicant_id = ? `,
                [ids],
                (err, technology) => {
                  if (err) {
                    console.log("error in technology" + err);
                  }

                  db.query(
                    `select company_name,designation,from_date,to_date from work_experience where applicant_id = ?`,
                    [ids],
                    (err, experience) => {
                      if (err) {
                        console.log("error in work_experience" + err);
                      }

                      db.query(
                        `select full_name,contact_number,relation from references_contact where applicant_id = ?`,
                        [ids],
                        (err, contact_reference) => {
                          if (err) {
                            console.log("error in references_contact" + err);
                          }

                          db.query(
                            `select prefered_location,notice_period,department,expected_ctc,current_ctc from preferances where applicant_id = ?`,
                            [ids],
                            (err, preferance) => {
                              if (err) {
                                console.log("error in preferances" + err);
                              }

                              callback(
                                err,
                                applicants,
                                educations,
                                experience,
                                languages,
                                technology,
                                contact_reference,
                                preferance,
                                ids,
                              );
                              return;
                            },
                          );
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        },
      );
    },
  );
};

const updateapplicant = function (id,body,callback) {
  db.query(`update applicants set first_name='${body.fname}',
                        last_name='${body.lname}',
                        designation='${body.designation}',
                        address1='${body.address1}',
                        address2='${body.address2}',
                        email='${body.email}',
                        country_id=${body.country},
                        state_id=${body.state},
                        city_id=${body.city},
                        zip_code='${body.zipcode}',
                        phone_no='${body.phone_no}',
                        gender='${body.gender}',
                        relationship_status='${body.relationship}',
                        date_of_birth='${body.dob}' where applicant_id=${id}`,callback);
};

const deleteapplicants = function (id, callback) {
    db.query("delete from applicants where applicant_id = ?", [id], callback);
}
module.exports = {
  insertapplicant,
  getapplicants,
  getapplicantinfromation,
  updateapplicant,
  deleteapplicants
};
