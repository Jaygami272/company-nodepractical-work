
const db=require("../configs/db");

const insertlanguagestatus=(languagestatus,callback)=>{
        db.query("Insert into languages_known (applicant_id,language_name,read_language,write_language,speak_language) values ? ",[languagestatus],callback);
}

const deletelanguagestatus=(id,callback)=>{
        db.query(`Delete from languages_known where applicant_id =${id}`,callback);
}

module.exports={
    insertlanguagestatus,
    deletelanguagestatus
}