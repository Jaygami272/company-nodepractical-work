const db=require('../configs/db');

let gettechnology=function(callback){
        db.query('select technology_id,technology_name from technologies',callback);
}

module.exports={
     gettechnology
}