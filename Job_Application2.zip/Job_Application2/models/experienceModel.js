const db=require("../configs/db");

const insertexperience=(experience,callback)=>{
    db.query("Insert into work_experience(applicant_id,company_name,designation,from_date,to_date) values ? ",[experience],callback);
}

const deleteexperience=(id,callback)=>{
    db.query(`Delete from work_experience where applicant_id=${id}`,callback);
}

module.exports={
    insertexperience,
    deleteexperience
}