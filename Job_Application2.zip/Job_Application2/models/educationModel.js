
const db=require("../configs/db");

const inserteducation=(education,callback)=>{
                    db.query("insert into educations(applicant_id,course_name,university_board,passing_year,percentage) values ? ",[education],callback);
}

const deleteeducation=(id,callback)=>{
    db.query(`delete from educations where applicant_id=${id}`,callback);
}

module.exports={
    inserteducation,
    deleteeducation,
}