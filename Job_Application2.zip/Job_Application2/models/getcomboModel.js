
const db=require("../configs/db");

const getcombobox=(code,callback)=>{
        db.query(`select s.select_type,s.select_name,o.option_value,o.option_label from selectmasters as s join optionmasters as o on s.select_master_id=o.select_master_id where s.select_code='${code}'`,callback);
}

module.exports={
    getcombobox
}