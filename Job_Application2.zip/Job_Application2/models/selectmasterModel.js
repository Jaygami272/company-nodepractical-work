const db=require("../configs/db");


const getselectmaster=(callback)=>{
        db.query("select s.select_type,s.select_id,s.select_name ,o.option_value from selectmasters as s join optionmasters as o on s.select_master_id=o.select_master_id",callback);
};


module.exports={
    getselectmaster
}