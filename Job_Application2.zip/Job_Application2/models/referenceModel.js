const db=require('../configs/db');

const insertreference=(reference,callback)=>{
       db.query("insert into references_contact(applicant_id,full_name,contact_number,relation) values ?  ",[reference],callback);

}

const deletereference=(id,callback)=>{
    db.query(`Delete from references_contact where applicant_id=${id}`,callback);
}

module.exports={
    insertreference,
    deletereference
}