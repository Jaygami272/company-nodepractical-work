const db=require('../configs/db');

function getstate(country_id,callback){
    db.query(`select state_id,state_name from states where country_id=${country_id}`,callback);
}

module.exports={
    getstate
}