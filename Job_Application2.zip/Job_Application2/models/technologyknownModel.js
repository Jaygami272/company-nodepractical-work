const db=require("../configs/db");

const inserttechstatus=(techstatus,callback)=>{
        db.query("Insert into technologies_known(applicant_id,technology_name,levels) values ?",[techstatus],callback);
}

const deletetechstatus=(id,callback)=>{
        db.query(`Delete from technologies_known where applicant_id=${id}`,callback);
}

module.exports={
    inserttechstatus,
    deletetechstatus
}