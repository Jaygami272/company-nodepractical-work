const db=require('../configs/db');

function getcountry(callback){
    db.query(`select country_id,country_name from countries`,callback);
}

module.exports={
    getcountry
}