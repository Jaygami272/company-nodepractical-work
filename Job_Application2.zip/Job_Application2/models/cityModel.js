const db=require('../configs/db');

function getcity(state_id,callback){
    db.query(`select city_id,city_name from cities where state_id = ${state_id}`,callback);
}

module.exports={
    getcity
}