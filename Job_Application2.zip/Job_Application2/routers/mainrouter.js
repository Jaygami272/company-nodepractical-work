const express=require('express');
const router=express.Router();
const technology_model=require("../models/technologyModel");
const countrymodel=require("../models/countryModel");
const statemodel=require("../models/stateModel");
const citymodel=require("../models/cityModel");
const language_model=require("../models/languageModel");
const selectmodel=require("../models/selectmasterModel");
const applicantcontroller=require("../controllers/applicantsController");
 router.post('/insertapplicant',applicantcontroller.addapplicants);
router.get('/viewapplicants',applicantcontroller.retriveapplicants);
router.get('/editinformation',applicantcontroller.editapplicantdeatil);
router.put('/updatedetails',applicantcontroller.updateapplicantdetails);
router.get('/viewinformation',applicantcontroller.retriveapplicantdetail);
router.get('/deleteinformation',applicantcontroller.deleteapplicants);
router.get('/',(req,res)=>{
        let technology;
        let country;
        let gender;
        let relationship;
        let relationshipobj={};
        technology_model.gettechnology((err,data)=>{
                technology=data;
               // console.log(technology);
        });
        
        countrymodel.getcountry((err,data)=>{
           
        country=data;
               
        });

        selectmodel.getselectmaster((err,data)=>{
                let relationshiparray=[];
                
                gender=data.filter(data=>data.select_name=="gender");
                relationship=data.filter(datas=>datas.select_name=="relationship");
                relationship.forEach(r => {
                        relationshipobj.select_id=r.select_id,
                        relationshipobj.select_name=r.select_name,
                        relationshipobj.option_value=[];
                });

                relationship.forEach(r=>{
                        relationshipobj.option_value.push(r.option_value);
                });

                

                console.log(relationshipobj);
                
        });



        language_model.getlanguage((err,result)=>{
                if(err){
                        console.log("error occure while fetch languages")
                }else{

                        
                         
                       // console.log(relationship);
                        // return;
                       
                        res.render('job_application_form',{result,technology,country,gender,relationshipobj});
                }
                 
        });
    
});

router.get('/getstate',(req,res)=>{
        
        statemodel.getstate(req.query.country,(err,states)=>{
                res.json(states);
        });
});

router.get('/getcity',(req,res)=>{
        citymodel.getcity(req.query.state,(err,cities)=>{
                
                res.json(cities);
        });
});

module.exports=router;
