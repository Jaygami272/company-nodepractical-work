const db=require('./configs/db');
const express=require('express');
const app=express();
const mainrouter=require("./routers/mainrouter1");
const router=express.Router();

app.use(express.urlencoded({extended:true}));
app.use(express.json());
app.use('/',mainrouter);
app.use(router);

app.set('view engine','ejs');
app.use(express.static('public'));

app.listen(process.env.PORT,(err)=>{
        if(err) throw err;
        console.log("Server Start..");
});