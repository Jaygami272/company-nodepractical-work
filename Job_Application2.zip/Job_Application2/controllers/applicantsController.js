const applicantmodel = require("../models/applicantsModel");
const educationmodel = require("../models/educationModel");
const experiencemodel = require("../models/experienceModel");
const languageknownmodel = require("../models/languageknownModel");
const technologyknownmodel = require("../models/technologyknownModel");
const referencemodel = require("../models/referenceModel");
const preferencemodel = require("../models/preferenceModel");
const technologymodel = require("../models/technologyModel");
const languagemodel = require("../models/languageModel");
const countrymodel = require("../models/countryModel");
const statemodel = require("../models/stateModel");
const citymodel = require("../models/cityModel");

const addapplicants = (req, res) => {
  return;
  const languagestatus = JSON.parse(req.body.langarray);
  const technologystatus = JSON.parse(req.body.techarray);
  const referencecount = req.body.referencename;
  let insertedid;
  let educationparent = [];
  let educationchild = [];
  let experienceparent = [];
  let experiencechild = [];
  let languageparent = [];
  let languagechild = [];
  let technologychild = [];
  let technologyparent = [];
  let referenceparent = [];
  let referencechild = [];
  const body = req.body;

 
  applicantmodel.insertapplicant(req.body, (err, result) => {
    if (err) {
      console.log("Error occure while insert basic details.." + err);
      return;
    } else {
      insertedid = result.insertId;
      console.log("Applicants basic details insert successfully..");
    }

    for (let i = 0; i < req.body.coursename.length; i++) {
      educationchild.push(
        insertedid,
        body.coursename[i],
        body.university[i],
        body.passingyear[i],
        body.percentage[i],
      );
      educationparent.push(educationchild);
      educationchild = [];
    }

    for (let i = 0; i < body.companyname.length; i++) {
      experiencechild.push(
        insertedid,
        body.companyname[i],
        body.designation[i],
        body.fromdate[i],
        body.todate[i],
      );
      experienceparent.push(experiencechild);
      experiencechild = [];
    }

    for (let i = 0; i < languagestatus.length; i++) {
      languagechild.push(
        insertedid,
        languagestatus[i].option_value,
        languagestatus[i].readlang,
        languagestatus[i].writelang,
        languagestatus[i].speaklang,
      );
      languageparent.push(languagechild);
      languagechild = [];
    }

    for (let m = 0; m < technologystatus.length; m++) {
      technologychild.push(
        insertedid,
        technologystatus[m].option_value,
        technologystatus[m].level,
      );
      technologyparent.push(technologychild);
      technologychild = [];
    }

    for (let n = 0; n < referencecount.length; n++) {
      referencechild.push(
        result.insertId,
        body.referencename[n],
        body.contact[n],
        body.relation[n],
      );
      referenceparent.push(referencechild);
      referencechild = [];
    }

    educationmodel.inserteducation(educationparent, (err, education) => {
      if (err) {
        console.log("Error occure while insert education details .." + err);
      } else {
        console.log("Eduction insert successfully..");
      }
    });

    experiencemodel.insertexperience(experienceparent, (err, experience) => {
      if (err) {
        console.log("Error occure while try to insert experience..." + err);
      } else {
        console.log("Experience insert successfully..");
      }
    });

    languageknownmodel.insertlanguagestatus(
      languageparent,
      (err, langaugeknown) => {
        if (err) {
          console.log(
            "Error occure while try to insert language known.." + err,
          );
        } else {
          console.log("Language Status insert successfully..");
        }
      },
    );

    technologyknownmodel.inserttechstatus(
      technologyparent,
      (err, technologyknown) => {
        if (err) {
          console.log(
            "Error occure while insert data into technologyknown.." + err,
          );
        } else {
          console.log("Technology status insert successfully..");
        }
      },
    );

    referencemodel.insertreference(referenceparent, (err, reference) => {
      if (err) {
        console.log("Error occure in reference contact table");
      } else {
        console.log("reference contact Insert Successfully..");
      }
    });

    preferencemodel.insertpreference(insertedid, body, (err, preferance) => {
      if (err) {
        console.log("Error occure in preference table", err);
      } else {
        console.log("preference Insert Successfully..");
        res.redirect('/viewapplicants');
      }
    });
  });
};

const retriveapplicants = (req, res) => {
  applicantmodel.getapplicants((err, result) => {
    if (err) throw err;

    res.render("job_application_all_applicants", { result });
  });
};

function editapplicantdeatil(req, res) {
  let id = req.query.id;

  let technology;
  let result;
  let country;
  let state;
  let city;
  technologymodel.gettechnology((err, data) => {
    technology = data;
  });
  languagemodel.getlanguage((err, results) => {
    if (err) {
      console.log("error occure while fetch languages");
    }
    result = results;
  });

  countrymodel.getcountry((err, countries) => {
    if (err) {
      console.log("error occure while fetch Country");
    }
    country = countries;
  });

  applicantmodel.getapplicantinfromation(
    id,
    (
      err,
      applicants,
      educations,
      experience,
      languages,
      technologys,
      contact_reference,
      preferance,
      id,
    ) => {
      if (err) {
        console.log("error while retrive " + err);
      }

      statemodel.getstate(applicants[0].country_id, (err, states) => {
        if (err) {
          console.log("error occure while fetch State");
          return;
        }
        state = states;

        citymodel.getcity(applicants[0].state_id, (err, cities) => {
          if (err) {
            console.log("error occure while fetch City");
            return;
          }
           city = cities;
          // console.log(applicants);
          // return;
          res.render("edit_applicant1", {
            applicants,
            educations,
            experience,
            languages,
            contact_reference,
            preferance,
            technology,
            result,
            technologys,
            id,
            country,
            state,
            city,
          });
        });
      });
    },
  );
}

function updateapplicantdetails(req, res) {
  let table = req.body.table;
  let body = req.body;
  // console.log(body);
  // return;
  if (table == "applicants") {
    applicantmodel.updateapplicant(req.query.id, body, (err, result) => {
      if (err) {
        console.log("Error occure while try to update applicant table.." + err);
      } else {
        console.log("Applicant update successfully..");
        res.status(200).json({ success: true });
      }
    });
  } else if (table == "education") {
    let educationparent = [];
    let educationchild = [];

    educationmodel.deleteeducation(req.query.id, (err, result) => {
      if (err) {
        console.log("Error occure while delete eduction " + err);
      }

      for (let i = 0; i < body.coursename.length; i++) {
        educationchild.push(
          req.query.id,
          body.coursename[i],
          body.university[i],
          body.passingyear[i],
          body.percentage[i],
        );
        educationparent.push(educationchild);
        educationchild = [];
      }

      educationmodel.inserteducation(educationparent, (err, result) => {
        if (err) {
          console.log("Error occure while updateing education details..");
        } else {
          console.log("Education update successfully..");
          res.status(200).json({ status: true });
        }
      });
    });
  } else if (table == "experience") {
    let experienceparent = [];
    let experiencechild = [];

    experiencemodel.deleteexperience(req.query.id, (err, result) => {
      if (err) {
        console.log("Error occure while delete experience.." + err);
      }

      for (let i = 0; i < body.companyname.length; i++) {
        experiencechild.push(
          req.query.id,
          body.companyname[i],
          body.designation1[i],
          body.fromdate[i],
          body.todate[i],
        );
        experienceparent.push(experiencechild);
        experiencechild = [];
      }

      experiencemodel.insertexperience(experienceparent, (err, result) => {
        if (err) {
          console.log("Error occure while insert experience.." + err);
        } else {
          console.log("Experiences update successfully...");
          res.status(200).json({ status: true });
        }
      });
    });
  } else if (table == "lang_tech") {
    let languagechild = [];
    let languageparent = [];
    let technologyparent=[];
    let technologychild=[];
    
    const langarray = JSON.parse(body.langarray);
    const techarray = JSON.parse(body.techarray);
    languageknownmodel.deletelanguagestatus(req.query.id, (err, result) => {
      if (err) {
        console.log("Error occure while delete from languageknown " + err);
      }


      technologyknownmodel.deletetechstatus(req.query.id,(err,result)=>{
            if(err){
              console.log("Error occure while delete from Technologyknown.."+err);
            }

            for (let i = 0; i < langarray.length; i++) {
        languagechild.push(
          parseInt(req.query.id),
          langarray[i].option_value,
          langarray[i].readlang,
          langarray[i].writelang,
          langarray[i].speaklang,
        );
        languageparent.push(languagechild);
        languagechild=[];
      }

      for(let i=0;i<techarray.length;i++){
        technologychild.push(parseInt(req.query.id),techarray[i].option_value, techarray[i].level);
        technologyparent.push(technologychild);
        technologychild=[];
      }

      
      languageknownmodel.insertlanguagestatus(languageparent,(err,result)=>{
                      if(err) throw err;
                      console.log("Language Status update successfully..");
                      

      });

      technologyknownmodel.inserttechstatus(technologyparent,(err,result)=>{
                        if(err){
                           console.log("Error occure while update technology status.."+err);
                        }
                        console.log("Technology Status update successfully..");
                        res.status(200).json({status:true});
      });

      });

      
    });
  }else if(table=="reference"){
        let referencechild=[];
        let referenceparent=[];
    referencemodel.deletereference(req.query.id,(err,result)=>{
                if(err){
                  console.log("Error occure while delete contact reference...");
                }

                for(let i=0;i<body.referencename.length;i++){
                  referencechild.push(req.query.id,body.referencename[i],body.contact[i],body.relation[i]);
                  referenceparent.push(referencechild);
                  referencechild=[];
                }

                referencemodel.insertreference(referenceparent,(err,callback)=>{
                        if(err){
                          console.log("Error occure while update contact reference..");
                        }
                        console.log("Contact reference update Successfully..");
                        res.status(200).json({status:true});
                });
    });
  }else if(table="preference"){

    
          preferencemodel.deletepreference(req.query.id,(err,result)=>{
                  if(err) throw err;

                  preferencemodel.insertpreference(req.query.id,body,(err,result)=>{
                        if(err) throw err;

                        res.status(200).json({status:true});
                  });
          });

  }
}

function retriveapplicantdetail(reqs, res) {
    let ids = reqs.query.id;

    applicantmodel.getapplicantinfromation(ids, (err, applicants, educations, experience, languages, technology, contact_reference, preferance, ids) => {
        if (err) {
            console.log("error while retrive " + err);
        };


        res.render('applicant_details', { applicants, educations, experience, languages, technology, contact_reference, preferance, ids });

    });
}

function deleteapplicants(req, res) {
    let id = req.query.id;

    applicantmodel.deleteapplicants(id, (err, result) => {
        if (err) throw err;

        res.redirect('/viewapplicants');
    });
}
module.exports = {
  addapplicants,
  retriveapplicants,
  editapplicantdeatil,
  updateapplicantdetails,
  retriveapplicantdetail,
  deleteapplicants
};
